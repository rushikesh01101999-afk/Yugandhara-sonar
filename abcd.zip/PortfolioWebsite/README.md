# Yugandhara Sonar - Portfolio Website

A modern, clean, and highly professional single-page portfolio website for a Java Full Stack Developer. Features a dark mode theme with sleek slate gray backgrounds, vibrant neon blue and subtle code-green accent colors.

## 🎨 Design Features

- **Dark Mode Theme**: Slate gray backgrounds (#0f172a, #1e293b, #334155)
- **Accent Colors**: Neon blue (#00d9ff) and code green (#10b981)
- **Hero Section**: Bold, minimalist typography with abstract tech/data flow background
- **Tech Stack Section**: Sleek, monochrome logos with hover effects
- **Fully Responsive**: Optimized for mobile, tablet, and desktop
- **Smooth Animations**: Scroll-triggered animations and hover effects
- **Modern UI/UX**: Clean, uncluttered interface with professional aesthetics

## 📁 Project Structure

```
PortfolioWebsite/
├── index.html              # Single-page portfolio
├── README.md               # This file
├── assets/
│   ├── css/
│   │   └── style.css      # Main stylesheet with dark theme
│   ├── js/
│   │   └── main.js        # Client-side interactions
│   └── images/
│       └── (for future images)
```

## 🚀 Getting Started

### Option 1: Open Directly in Browser
Simply double-click `index.html` to open it in your default web browser.

### Option 2: Use a Local Server (Recommended)
For the best experience, use a local development server:

**Using Python:**
```bash
cd PortfolioWebsite
python -m http.server 8000
```
Then open `http://localhost:8000` in your browser.

**Using Node.js (http-server):**
```bash
cd PortfolioWebsite
npx http-server -p 8000
```

**Using PHP:**
```bash
cd PortfolioWebsite
php -S localhost:8000
```

## 📱 Sections

1. **Hero Section**: Introduction with name, title, and call-to-action buttons
2. **About**: Profile summary and professional background
3. **Tech Stack**: Technologies organized by category (Backend, Frontend, Database, Tools)
4. **Experience**: Work experience timeline
5. **Projects**: Featured project showcase
6. **Education**: Academic qualifications and certifications
7. **Contact**: Contact information and languages

## 🛠️ Technologies Used

- **HTML5**: Semantic markup
- **CSS3**: Modern styling with CSS variables, flexbox, grid, and animations
- **JavaScript**: Vanilla JS for interactions (no dependencies)
- **Font Awesome**: Icons for tech stack and UI elements
- **Google Fonts**: Inter and JetBrains Mono fonts

## ✨ Features

- ✅ Fully responsive design (mobile-first approach)
- ✅ Smooth scroll navigation
- ✅ Scroll-triggered animations
- ✅ Mobile hamburger menu
- ✅ Active navigation link highlighting
- ✅ Scroll-to-top button
- ✅ Hover effects on interactive elements
- ✅ Dark mode optimized
- ✅ No server dependencies
- ✅ Client-side only (no API calls)

## 🎯 Customization

### Update Personal Information
Edit `index.html` to update:
- Name, title, location
- Contact information (phone, email)
- Experience details
- Project descriptions
- Education information

### Change Colors
Modify CSS variables in `assets/css/style.css`:
```css
:root {
    --bg-primary: #0f172a;        /* Main background */
    --accent-primary: #00d9ff;    /* Neon blue */
    --accent-secondary: #10b981;  /* Code green */
    /* ... more variables */
}
```

### Add More Projects
Duplicate the `.project-card` structure in the Projects section and update the content.

### Add More Tech Stack Items
Add new `.tech-item` divs within the appropriate `.tech-grid` container.

## 📄 License

This portfolio website is created for personal use. Feel free to use it as a template for your own portfolio.

## 👤 Author

**Yugandhara Sonar**
- Location: Pune, India
- Email: sonaryugandhara1@gmail.com
- Phone: +91-950 371 1538

---

Built with passion for clean code and modern web technologies. 🚀
